Created in:
----------
Java 1.8
jdk1.3

To execute Through CommandLine:
write:   java RockPaperSissors


Choose one option from given :

ROCK, PAPER, SCISSORS!

Rock, paper, or scissors? 

Note:  you can just type first letter of these given option.

for example: r

then computer will play agains you.

again then ask:
Do You want to play again? 

Enter y for continue:


